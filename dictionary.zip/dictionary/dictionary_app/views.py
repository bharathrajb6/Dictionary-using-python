from PyDictionary.test_pydictionary import dictionary
from django.shortcuts import render
from PyDictionary import PyDictionary


# Create your views here.

def index(request):
    if request.method == "POST":
        text = request.POST.get('text')
        d = dictionary.meaning(text)
        meaning = ''
        try:
            a = list(d.keys())
        except:
            a=None
        if a is not None:
            for i in a:
                if i == "Noun":
                    meaning = d[i]
                elif i == "Verb":
                    meaning = d[i]
                else:
                    meaning = d[i]
            string = ''
            print(meaning)
            for i in meaning:
                string += i
            #string = string.replace(',', '.')
            string = string.replace(';','.')
            print(string)
            synonym = dictionary.synonym(text)
            antonym = dictionary.antonym(text)

            return render(request, 'index.html', {'meaning': string, 'synonym': synonym, 'antonym': antonym})
        else:
            return render(request,"index.html",{"meaning":None,"synonym":None,"antonym":None})


    else:
        return render(request, 'index.html')
